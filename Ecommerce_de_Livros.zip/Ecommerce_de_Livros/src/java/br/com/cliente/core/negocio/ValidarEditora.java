package br.com.cliente.core.negocio;

import br.com.cliente.dominio.Livro;
import br.com.cliente.dominio.EntidadeDominio;

public class ValidarEditora implements IStrategy {

    @Override
    public String processar(EntidadeDominio entidade) {

        System.out.println("Validação da Editora do Livro...");
        Livro livro = (Livro) entidade;
        String msg = "";
        boolean flag = false;

        if (livro.getEditora() != null || !livro.getEditora().trim().equals("")) {

            if ((livro.getEditora().equals("Globo")) || (livro.getEditora().equals("Abril")) || (livro.getEditora().equals("Cultura")) || (livro.getEditora().equals("Saraiva"))) {

                flag = livro.getEditora().matches(livro.getEditora());

                if (flag == false) {
                    msg = msg + "ISBN Invalido!!! ";
                }

            } else {

                msg = msg + "Registro Não Gravado - Editora inválida.\n Editora inválida (Editoras autorizadas - Globo, Abril, Cultura, Saraiva) ";
            }
        }
        System.out.println("Foi checado a Editora do livro: " + flag);
        System.out.println("______________________________________ ");
        if (msg.equals("")) {
            return null;
        }
        return msg;
    }
}

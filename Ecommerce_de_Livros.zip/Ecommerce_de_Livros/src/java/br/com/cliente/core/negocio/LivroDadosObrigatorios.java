package br.com.cliente.core.negocio;


import br.com.cliente.dominio.EntidadeDominio;
import br.com.cliente.dominio.Livro;

public class LivroDadosObrigatorios implements IStrategy {

    @Override
    public String processar(EntidadeDominio entidade) {

        Livro livro = (Livro) entidade;
        String msg = "";
        if (livro.getTitulo() == null || livro.getTitulo().trim().equals("")) {
            msg = msg + "Registro Não Gravado - Titulo do Livro não informado.\n";
        }

        if (livro.getAutor() == null || livro.getAutor().trim().equals("")) {
            msg = msg + "Registro Não Gravado - Autor do Livro não informado.\n";
        }

        if (livro.getDescricao() == null || livro.getDescricao().trim().equals("")) {
            msg = msg + "Registro Não Gravado - Descrição do Livro não informado.\n";
        }

        if (livro.getPreco() == null) {
            msg = msg + "Registro Não Gravado - Preco do Livro não informado.\n";
        }

        System.out.println("Checando os dados do livro a ser cadastrado....!!!");
        System.out.println("__________________________________________________");

        if (msg.equals("")) {
            return null;
        }
        return msg;
    }
}

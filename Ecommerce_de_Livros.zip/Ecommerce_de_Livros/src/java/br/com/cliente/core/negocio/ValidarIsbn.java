package br.com.cliente.core.negocio;

import br.com.cliente.dominio.Livro;
import br.com.cliente.dominio.EntidadeDominio;

public class ValidarIsbn implements IStrategy {

    @Override
    public String processar(EntidadeDominio entidade) {
        
        System.out.println("Validação do ISBN do Livro...");
        Livro livro = (Livro) entidade;
        String msg = "";
        boolean flag = false;

        if (livro.getIsbn() != null || !livro.getIsbn().trim().equals("")) {
            
            if (livro.getIsbn().length() != 13) {
                flag = livro.getIsbn().matches(livro.getIsbn());

                if (flag == false) {
                    msg = "ISBN inválido.";
                }

                msg = msg + " Registro Não Gravado - ISBN Inválido!!!";
                
            }
        }
        System.out.println("\n");
        System.out.println(msg + "Foi checado o ISBN do livro " );
        System.out.println("_________________________________ ");
        if (msg.equals("")) {
            return null;
        }
        return msg;
    }
}

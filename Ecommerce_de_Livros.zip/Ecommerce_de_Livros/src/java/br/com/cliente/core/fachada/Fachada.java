package br.com.cliente.core.fachada;

import br.com.cliente.core.dao.IDAO;
import br.com.cliente.core.dao.LivroDAO;
import br.com.cliente.core.negocio.LivroDadosObrigatorios;
import br.com.cliente.core.negocio.IStrategy;
import br.com.cliente.core.negocio.ValidarIsbn;
import br.com.cliente.core.negocio.ValidarEditora;
import br.com.cliente.dominio.Livro;
import br.com.cliente.dominio.EntidadeDominio;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Fachada implements IFachada {

    /**
     * Mapa de DAOS, será indexado pelo nome da entidade;
     *
     */
    private Map<String, IDAO> daos;

    /**
     * Mapa para conter as regras de negócio de todas as operações por entidade;
     *
     */
    private Map<String, Map<String, List<IStrategy>>> regras;

    //Para conter as mensagem de resultado
    Resultado resultado;

    public Fachada() {
        /* Intanciando o Map de DAOS */
        daos = new HashMap<String, IDAO>();

        /* Intanciando o Map de Regras de Negócio */
        regras = new HashMap<String, Map<String, List<IStrategy>>>();

        /* Criando instancias dos DAOs a serem utilizados*/
        LivroDAO livroDAO = new LivroDAO();

        /* Adicionando cada dao no MAP indexando pelo nome da classe */
        // daos.put(Cliente.class.getName(), vooDAO);
        daos.put(Livro.class.getName(), livroDAO);

        /* Criando instâncias de regras de negócio a serem utilizados*/
        LivroDadosObrigatorios livroDadosObrigatorios = new LivroDadosObrigatorios();
        ValidarIsbn validarIsbn = new ValidarIsbn();
        ValidarEditora validarEditora = new ValidarEditora();

        List<IStrategy> regrasSalvarLivros = new ArrayList<IStrategy>();
        /* Adicionando as regras a serem utilizadas na operação salvar do cliente*/
        regrasSalvarLivros.add(livroDadosObrigatorios);
        regrasSalvarLivros.add(validarIsbn);
        regrasSalvarLivros.add(validarEditora);

        /* Criando uma lista para conter as regras de negócio de cliente
		 * quando a operação for atuallizar
         */
        List<IStrategy> regrasAtualizarLivro = new ArrayList<IStrategy>();
        /* Adicionando as regras a serem utilizadas na operação atualizar do cliente*/
        regrasAtualizarLivro.add(livroDadosObrigatorios);
        regrasAtualizarLivro.add(validarIsbn);
        regrasAtualizarLivro.add(validarEditora);
        /* Cria o mapa que poderá conter todas as listas de regras de negócio específica 
		 * por operação  do cliente
         */
        Map<String, List<IStrategy>> regrasLivro = new HashMap<String, List<IStrategy>>();
        /*
		 * Adiciona a listra de regras na operação salvar no mapa do cliente
         */
        regrasLivro.put("SALVAR", regrasSalvarLivros);
        regrasLivro.put("ATUALIZAR", regrasAtualizarLivro);

        regras.put(Livro.class.getName(), regrasLivro);

    }

    public String executarRegras(EntidadeDominio entidade, String operacao) {

        String nomeDaClasse = entidade.getClass().getName();
        StringBuilder mensagens = new StringBuilder();

        Map<String, List<IStrategy>> regrasOperacao = regras.get(nomeDaClasse);

        if (regrasOperacao != null) {
            List<IStrategy> regras = regrasOperacao.get(operacao);

            if (regras != null) {
                int i = 0;
                for (IStrategy r : regras) {

                    String msg = r.processar(entidade);
                    System.out.println("Livro nº " + i + " Checado : " + msg);
                    System.out.println("___________________________________");
                    if (msg != null) {
                        mensagens.append(msg);
                        mensagens.append("\n");
                    }
                    i++;
                }
            }
        }

        if (mensagens.length() > 0) {
            return mensagens.toString();
        } else {
            return null;
        }

    }

    @Override
    public Resultado salvar(EntidadeDominio entidade) {

        resultado = new Resultado();

        String nmClasse = entidade.getClass().getName();

        String msg = executarRegras(entidade, "SALVAR");

        if (msg == null) {
            IDAO dao = daos.get(nmClasse);
            if (dao instanceof LivroDAO) {
                try {
                    dao.salvar(entidade);
                    List<EntidadeDominio> entidades = new ArrayList<>();
                    entidades.add(entidade);
                    resultado.setEntidades(entidades);
                } catch (SQLException e) {
                    e.printStackTrace();
                    resultado.setMsg("Não foi possível realizar o cadastro deste livro!!!");
                }
            }
            
            }else {
                resultado.setMsg(msg);
                System.out.println("seta msg erro");
            }
        
        return resultado;

    }

    @Override
    public Resultado salvar(EntidadeDominio entidadeCli, EntidadeDominio entidadeAlt) {

        return resultado;
    }

    @Override
    public Resultado atualizar(EntidadeDominio entidade) {
        resultado = new Resultado();

        String nmClasse = entidade.getClass().getName();

        //String msg = executarRegras(entidade, "ATUALIZAR");
        // if (msg == null) {
        IDAO dao = daos.get(nmClasse);
        try {
            dao.atualizar(entidade);
            List<EntidadeDominio> entidades = new ArrayList<EntidadeDominio>();
            entidades.add(entidade);
            resultado.setEntidades(entidades);
        } catch (SQLException e) {
            e.printStackTrace();
            resultado.setMsg("Não foi possível realizar o cadastro deste livro!!!");

        }

        System.out.println("Houve um erro no processamento da Fachada?");
        return resultado;

    }

    @Override
    public Resultado excluir(EntidadeDominio entidade) {
        resultado = new Resultado();

        String nmClasse = entidade.getClass().getName();

        //String msg = executarRegras(entidade, "EXCLUIR");
        //if(msg == null){
        IDAO dao = daos.get(nmClasse);
        try {
            dao.excluir(entidade);
            List<EntidadeDominio> entidades = new ArrayList<EntidadeDominio>();
            entidades.add(entidade);
            resultado.setEntidades(entidades);
        } catch (SQLException e) {
            e.printStackTrace();
            resultado.setMsg("Não foi possível excluir o cadastro deste livro!!!");

        }

        return resultado;
    }

    @Override
    public Resultado consultar(EntidadeDominio entidade) {
        resultado = new Resultado();

        String nmClasse = entidade.getClass().getName();

        //String msg = executarRegras(entidade, "CONSULTAR");
        //if(msg == null){
        IDAO dao = daos.get(nmClasse);
        try {
            List<EntidadeDominio> entidades = dao.consultar(entidade);
            resultado.setEntidades(entidades);
        } catch (SQLException e) {
            e.printStackTrace();
            resultado.setMsg("Não foi possível consultar o cadastro de nenhum livro!!!");

        }

        return resultado;
    }

    @Override
    public Resultado visualizar(EntidadeDominio entidade
    ) {
        resultado = new Resultado();

        resultado.setEntidades(new ArrayList<EntidadeDominio>());
        resultado.getEntidades().add(entidade);
        return resultado;

    }

    @Override
    public Resultado listarfiltro(EntidadeDominio entidade
    ) {
        resultado = new Resultado();

        String nomeClasse = entidade.getClass().getName();
        //	String mensagem = executarRegras(entidade, "LISTARFILTRO");

        //if(mensagem == null){
        IDAO dao = daos.get(nomeClasse);

        try {
            resultado.setEntidades(dao.filtrar(entidade));

        } catch (Exception e) {
            e.printStackTrace();
            resultado.setMsg("Não foi possível realizar a consulta do livro!!!");
        } //fim try/catch
        //} else {
        //	resultado.setMsg(mensagem);
        //} // fim if

        return resultado;
    }

}

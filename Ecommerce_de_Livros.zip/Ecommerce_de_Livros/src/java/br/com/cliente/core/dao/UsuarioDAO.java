package br.com.cliente.core.dao;

import br.com.cliente.core.util.Conexao;
import br.com.cliente.dominio.EntidadeDominio;
import br.com.cliente.dominio.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDAO implements IDAO {

    PreparedStatement pst;
    Connection conexao;

    @Override
    public void salvar(EntidadeDominio entidade) {
        Usuario usuario = (Usuario) entidade;

        try {
            // Abre uma conexao com o banco.
            conexao = Conexao.getConexao();

            StringBuilder sql = new StringBuilder();
            sql.append("INSERT INTO usuario (dt_cadastro, login, senha, nome");
            sql.append(" VALUES(?, ?, ?, ?)");
            pst = conexao.prepareStatement(sql.toString(), Statement.RETURN_GENERATED_KEYS);

            pst.setDate(1, new java.sql.Date(System.currentTimeMillis()));
            pst.setString(2, usuario.getLogin());
            pst.setString(3, usuario.getSenha());
            pst.setString(4, usuario.getNome());    
            pst.execute();
            ResultSet generatedKeys = pst.getGeneratedKeys();
            if (null != generatedKeys && generatedKeys.next()) {
                usuario.setId(generatedKeys.getInt(1));
            }

        } catch (ClassNotFoundException erro) {
            erro.printStackTrace();

        } catch (SQLException erro) {
            erro.printStackTrace();

        } finally {
            try {
                pst.close();
                conexao.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

    }

    @Override
    public void atualizar(EntidadeDominio entidade) throws SQLException {

        Usuario usuario = (Usuario) entidade;

        if (usuario.getId() != 0) {
            try {
                // Abre uma conexao com o banco.
                conexao = Conexao.getConexao();

                StringBuilder sql = new StringBuilder();
                sql.append("UPDATE usuario  SET login =?, senha=?, nome=? WHERE id=" + usuario.getId());

                pst = conexao.prepareStatement(sql.toString());
                pst.setString(1, usuario.getLogin());
                pst.setString(2, usuario.getSenha());
                pst.setString(3, usuario.getNome());
        
                pst.execute();

            } catch (ClassNotFoundException erro) {
                erro.printStackTrace();

            } catch (SQLException erro) {
                erro.printStackTrace();

            } finally {
                try {
                    pst.close();
                    conexao.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    @Override
    public void excluir(EntidadeDominio entidade) {

        Usuario usuario = (Usuario) entidade;
        if (usuario.getId() != 0) {
            try {
                List<EntidadeDominio> usuarios = this.consultar(entidade);
                usuario = (Usuario) usuarios.get(0);
                // Abre uma conexao com o banco.
                conexao = Conexao.getConexao();

                StringBuilder sql = new StringBuilder();
                sql.append("DELETE FROM usuario * WHERE id = ?");

                pst = conexao.prepareStatement(sql.toString());
                pst.setInt(1, usuario.getId());
                pst.execute();

            } catch (ClassNotFoundException erro) {
                erro.printStackTrace();

            } catch (SQLException erro) {
                erro.printStackTrace();

            } finally {
                try {
                    pst.close();
                    conexao.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

    }

    @Override
    public List<EntidadeDominio> consultar(EntidadeDominio entidade) throws SQLException {

        List<EntidadeDominio> usuarios = new ArrayList<>();
        Usuario usuario = (Usuario) entidade;
        System.out.println("usuario dao" + usuario.getId());

        try {

            // Abre uma conexao com o banco.
            conexao = Conexao.getConexao();
            if (usuario.getId() != null) {
                StringBuilder sql = new StringBuilder();
                sql.append("SELECT * FROM usuario WHERE id=?");
                pst = conexao.prepareStatement(sql.toString());
                pst.setInt(1, usuario.getId());
                ResultSet rs = pst.executeQuery();
                while (rs.next()) {

                    usuario.setLogin(rs.getString("login"));
                    usuario.setSenha(rs.getString("senha"));
                    usuario.setNome(rs.getString("nome"));
              
                }
                usuarios.add(usuario);
            } else if (usuario.getLogin()!= null) {
                StringBuilder sql = new StringBuilder();
                sql.append("SELECT * FROM usuario WHERE login LIKE ?");
                pst = conexao.prepareStatement(sql.toString());
                pst.setString(1, '%' + usuario.getLogin()+ '%');
                ResultSet rs = pst.executeQuery();
                while (rs.next()) {

                    usuario = new Usuario();

                    usuario.setId(Integer.parseInt(rs.getString("id")));
                    usuario.setLogin(rs.getString("login"));
                    usuario.setSenha(rs.getString("senha"));
                    usuario.setNome(rs.getString("nome"));
               
                    usuarios.add(usuario);
                }
            } else {
                StringBuilder sql = new StringBuilder();
                sql.append("SELECT * FROM usuario");
                pst = conexao.prepareStatement(sql.toString());
                ResultSet rs = pst.executeQuery();
                while (rs.next()) {
                    usuario = new Usuario();

                    usuario.setId(Integer.parseInt(rs.getString("id")));
                    usuario.setLogin(rs.getString("login"));
                    usuario.setSenha(rs.getString("senha"));
                    usuario.setNome(rs.getString("nome"));
                    
                    usuarios.add(usuario);
                }
            }

        } catch (ClassNotFoundException erro) {
            erro.printStackTrace();
            //throw new ExcecaoAcessoDados("Houve um problema de configuração");
        } catch (SQLException erro) {
            erro.printStackTrace();
            //throw new ExcecaoAcessoDados("Houve um problema de conectividade");
        } finally {
            try {
                pst.close();
                conexao.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return usuarios;

    }

    @Override
    public int salvarId(EntidadeDominio entidade) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<EntidadeDominio> filtrar(EntidadeDominio entidade) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}

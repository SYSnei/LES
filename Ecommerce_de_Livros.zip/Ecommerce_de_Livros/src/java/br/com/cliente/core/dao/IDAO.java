
package br.com.cliente.core.dao;


import br.com.cliente.dominio.EntidadeDominio;
import java.sql.SQLException;
import java.util.List;


public interface IDAO {

	public void salvar(EntidadeDominio entidade) throws SQLException;
	public void atualizar(EntidadeDominio entidade)throws SQLException;
	public void excluir(EntidadeDominio entidade)throws SQLException;
	public List<EntidadeDominio> consultar(EntidadeDominio entidade)throws SQLException;
	public int salvarId(EntidadeDominio entidade) throws SQLException;
	public List<EntidadeDominio> filtrar(EntidadeDominio entidade) throws SQLException;
}
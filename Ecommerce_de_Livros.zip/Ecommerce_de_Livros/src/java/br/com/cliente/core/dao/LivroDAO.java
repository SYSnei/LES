package br.com.cliente.core.dao;

import br.com.cliente.core.util.Conexao;
import br.com.cliente.dominio.EntidadeDominio;
import br.com.cliente.dominio.Livro;
import static java.lang.Integer.getInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class LivroDAO implements IDAO {

    PreparedStatement pst;
    Connection conexao;

    @Override
    public void salvar(EntidadeDominio entidade) {
        Livro livro = (Livro) entidade;

        try {
            // Abre uma conexao com o banco.
            conexao = Conexao.getConexao();

            StringBuilder sql = new StringBuilder();
            sql.append("INSERT INTO livro (dt_cadastro, titulo, autor, descricao, isbn, ano, editora, paginas, situacao, preco, fotoBase64,contentType)");
            sql.append(" VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            pst = conexao.prepareStatement(sql.toString(), Statement.RETURN_GENERATED_KEYS);

            pst.setDate(1, new java.sql.Date(System.currentTimeMillis()));
            pst.setString(2, livro.getTitulo());
            pst.setString(3, livro.getAutor());
            pst.setString(4, livro.getDescricao());
            pst.setString(5, livro.getIsbn());
            pst.setString(6, livro.getAno());
            pst.setString(7, livro.getEditora());
            pst.setString(8, livro.getPaginas());
            pst.setString(9, livro.getSituacao());
            pst.setDouble(10, livro.getPreco());
            pst.setString(11, livro.getFotoBase64());
            pst.setString(12, livro.getContentType());

            pst.execute();
            ResultSet generatedKeys = pst.getGeneratedKeys();
            if (null != generatedKeys && generatedKeys.next()) {
                livro.setId(generatedKeys.getInt(1));
            }

        } catch (ClassNotFoundException erro) {
            erro.printStackTrace();

        } catch (SQLException erro) {
            erro.printStackTrace();

        } finally {
            try {
                pst.close();
                conexao.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

    }

    @Override
    public void atualizar(EntidadeDominio entidade) throws SQLException {

        Livro livro = (Livro) entidade;

        if (livro.getId() != 0) {
            try {
                // Abre uma conexao com o banco.
                conexao = Conexao.getConexao();

                StringBuilder sql = new StringBuilder();
                sql.append("UPDATE livro SET titulo =?, autor=?, descricao=?, isbn=?, ano=?, editora=?, paginas=?, situacao=?, preco=? WHERE id=" + livro.getId());

                pst = conexao.prepareStatement(sql.toString());
                pst.setString(1, livro.getTitulo());
                pst.setString(2, livro.getAutor());
                pst.setString(3, livro.getDescricao());
                pst.setString(4, livro.getIsbn());
                pst.setString(5, livro.getAno());
                pst.setString(6, livro.getEditora());
                pst.setString(7, livro.getPaginas());
                pst.setString(8, livro.getSituacao());
                pst.setDouble(9, livro.getPreco());
                //pst.setString(10, livro.getFotoBase64());
                //pst.setString(11, livro.getContentType());
                pst.execute();

            } catch (ClassNotFoundException erro) {
                erro.printStackTrace();

            } catch (SQLException erro) {
                erro.printStackTrace();

            } finally {
                try {
                    pst.close();
                    conexao.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    @Override
    public void excluir(EntidadeDominio entidade) {

        Livro livro = (Livro) entidade;
        if (livro.getId() != 0) {
            try {
                List<EntidadeDominio> livros = this.consultar(entidade);
                livro = (Livro) livros.get(0);
                // Abre uma conexao com o banco.
                conexao = Conexao.getConexao();

                StringBuilder sql = new StringBuilder();
                sql.append("DELETE FROM livro * WHERE id = ?");

                pst = conexao.prepareStatement(sql.toString());
                pst.setInt(1, livro.getId());
                pst.execute();

            } catch (ClassNotFoundException erro) {
                erro.printStackTrace();

            } catch (SQLException erro) {
                erro.printStackTrace();

            } finally {
                try {
                    pst.close();
                    conexao.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

    }

    @Override
    public List<EntidadeDominio> consultar(EntidadeDominio entidade) throws SQLException {

        List<EntidadeDominio> livros = new ArrayList<>();
        Livro livro = (Livro) entidade;
        System.out.println("livro dao" + livro.getId());

        try {

            // Abre uma conexao com o banco.
            conexao = Conexao.getConexao();
            if (livro.getId() != null) {
                StringBuilder sql = new StringBuilder();
                sql.append("SELECT * FROM livro WHERE id=?");
                pst = conexao.prepareStatement(sql.toString());
                pst.setInt(1, livro.getId());
                ResultSet rs = pst.executeQuery();
                while (rs.next()) {

                    livro.setTitulo(rs.getString("titulo"));
                    livro.setAutor(rs.getString("autor"));
                    livro.setDescricao(rs.getString("descricao"));
                    livro.setIsbn(rs.getString("isbn"));
                    livro.setAno(rs.getString("ano"));
                    livro.setEditora(rs.getString("editora"));
                    livro.setPaginas(rs.getString("paginas"));
                    livro.setSituacao(rs.getString("situacao"));
                    livro.setPreco(rs.getDouble("preco"));
                    livro.setFotoBase64(rs.getString("fotoBase64"));
                    livro.setContentType(rs.getString("contentType"));

                }
                livros.add(livro);
            } else if (livro.getTitulo() != null) {
                StringBuilder sql = new StringBuilder();
                sql.append("SELECT * FROM livro WHERE titulo LIKE ?");
                pst = conexao.prepareStatement(sql.toString());
                pst.setString(1, '%' + livro.getTitulo() + '%');
                ResultSet rs = pst.executeQuery();
                while (rs.next()) {

                    livro = new Livro();

                    livro.setId(Integer.parseInt(rs.getString("id")));
                    livro.setTitulo(rs.getString("titulo"));
                    livro.setAutor(rs.getString("autor"));
                    livro.setDescricao(rs.getString("descricao"));
                    livro.setIsbn(rs.getString("isbn"));
                    livro.setAno(rs.getString("ano"));
                    livro.setEditora(rs.getString("editora"));
                    livro.setPaginas(rs.getString("paginas"));
                    livro.setSituacao(rs.getString("situacao"));
                    livro.setPreco(rs.getDouble("preco"));
                    livro.setFotoBase64(rs.getString("fotoBase64"));
                    livro.setContentType(rs.getString("contentType"));

                    livros.add(livro);
                }
            } else {
                StringBuilder sql = new StringBuilder();
                sql.append("SELECT * FROM livro");
                pst = conexao.prepareStatement(sql.toString());
                ResultSet rs = pst.executeQuery();
                while (rs.next()) {
                    livro = new Livro();
                    
                    livro.setId(Integer.parseInt(rs.getString("id")));
                    livro.setTitulo(rs.getString("titulo"));
                    livro.setAutor(rs.getString("autor"));
                    livro.setDescricao(rs.getString("descricao"));
                    livro.setIsbn(rs.getString("isbn"));
                    livro.setAno(rs.getString("ano"));
                    livro.setEditora(rs.getString("editora"));
                    livro.setPaginas(rs.getString("paginas"));
                    livro.setSituacao(rs.getString("situacao"));
                    livro.setPreco(rs.getDouble("preco"));
                    livro.setFotoBase64(rs.getString("fotoBase64"));
                    livro.setContentType(rs.getString("contentType"));

                    livros.add(livro);
                }
            }

        } catch (ClassNotFoundException erro) {
            erro.printStackTrace();
            //throw new ExcecaoAcessoDados("Houve um problema de configuração");
        } catch (SQLException erro) {
            erro.printStackTrace();
            //throw new ExcecaoAcessoDados("Houve um problema de conectividade");
        } finally {
            try {
                pst.close();
                conexao.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return livros;

    }

    @Override
    public int salvarId(EntidadeDominio entidade) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<EntidadeDominio> filtrar(EntidadeDominio entidade) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}

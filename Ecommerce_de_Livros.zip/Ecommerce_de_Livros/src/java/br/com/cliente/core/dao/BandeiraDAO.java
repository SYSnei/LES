
package br.com.cliente.core.dao;

import br.com.cliente.core.util.Conexao;
import br.com.cliente.dominio.Bandeira;
import br.com.cliente.dominio.EntidadeDominio;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class BandeiraDAO implements IDAO{
    
    
    PreparedStatement pst;
    Connection conexao;

    @Override
    public void salvar(EntidadeDominio entidade) {
        Bandeira bandeira = (Bandeira) entidade;

        try {
            // Abre uma conexao com o banco.
            conexao = Conexao.getConexao();

            StringBuilder sql = new StringBuilder();
            sql.append("INSERT INTO bandeira (dt_cadastro,nome");
            sql.append(" VALUES(?, ?)");
            pst = conexao.prepareStatement(sql.toString(), Statement.RETURN_GENERATED_KEYS);

            pst.setDate(1, new java.sql.Date(System.currentTimeMillis()));
            pst.setString(2, bandeira.getNome());            
            pst.execute();
            ResultSet generatedKeys = pst.getGeneratedKeys();
            if (null != generatedKeys && generatedKeys.next()) {
                bandeira.setId(generatedKeys.getInt(1));
            }

        } catch (ClassNotFoundException erro) {
            erro.printStackTrace();

        } catch (SQLException erro) {
            erro.printStackTrace();

        } finally {
            try {
                pst.close();
                conexao.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

    }

    @Override
    public void atualizar(EntidadeDominio entidade) throws SQLException {

        Bandeira bandeira = (Bandeira) entidade;

        if (bandeira.getId() != 0) {
            try {
                // Abre uma conexao com o banco.
                conexao = Conexao.getConexao();

                StringBuilder sql = new StringBuilder();
                sql.append("UPDATE bandeira  SET nome =? WHERE id=" + bandeira.getId());

                pst = conexao.prepareStatement(sql.toString());
                pst.setString(1, bandeira.getNome());
                        
                pst.execute();

            } catch (ClassNotFoundException erro) {
                erro.printStackTrace();

            } catch (SQLException erro) {
                erro.printStackTrace();

            } finally {
                try {
                    pst.close();
                    conexao.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    @Override
    public void excluir(EntidadeDominio entidade) {

        Bandeira bandeira = (Bandeira) entidade;
        if (bandeira.getId() != 0) {
            try {
                List<EntidadeDominio> bandeiras = this.consultar(entidade);
                bandeira = (Bandeira) bandeiras.get(0);
                // Abre uma conexao com o banco.
                conexao = Conexao.getConexao();

                StringBuilder sql = new StringBuilder();
                sql.append("DELETE FROM bandeira * WHERE id = ?");

                pst = conexao.prepareStatement(sql.toString());
                pst.setInt(1, bandeira.getId());
                pst.execute();

            } catch (ClassNotFoundException erro) {
                erro.printStackTrace();

            } catch (SQLException erro) {
                erro.printStackTrace();

            } finally {
                try {
                    pst.close();
                    conexao.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

    }

    @Override
    public List<EntidadeDominio> consultar(EntidadeDominio entidade) throws SQLException {

        List<EntidadeDominio> bandeiras = new ArrayList<>();
        Bandeira bandeira = (Bandeira) entidade;
        System.out.println("bandeira dao" + bandeira.getId());

        try {

            // Abre uma conexao com o banco.
            conexao = Conexao.getConexao();
            if (bandeira.getId() != null) {
                StringBuilder sql = new StringBuilder();
                sql.append("SELECT * FROM bandeira WHERE id=?");
                pst = conexao.prepareStatement(sql.toString());
                pst.setInt(1, bandeira.getId());
                ResultSet rs = pst.executeQuery();
                while (rs.next()) {

                    bandeira.setNome(rs.getString("nome"));
                                  
                }
                bandeiras.add(bandeira);
            } else if (bandeira.getNome()!= null) {
                StringBuilder sql = new StringBuilder();
                sql.append("SELECT * FROM bandeira WHERE nome LIKE ?");
                pst = conexao.prepareStatement(sql.toString());
                pst.setString(1, '%' + bandeira.getNome()+ '%');
                ResultSet rs = pst.executeQuery();
                while (rs.next()) {

                    bandeira = new Bandeira();

                    bandeira.setId(Integer.parseInt(rs.getString("id")));
                    bandeira.setNome(rs.getString("nome"));
                                   
                    bandeiras.add(bandeira);
                }
            } else {
                StringBuilder sql = new StringBuilder();
                sql.append("SELECT * FROM bandeira");
                pst = conexao.prepareStatement(sql.toString());
                ResultSet rs = pst.executeQuery();
                while (rs.next()) {
                    bandeira = new Bandeira();

                    bandeira.setId(Integer.parseInt(rs.getString("id")));
                    bandeira.setNome(rs.getString("nome"));
                    
                    
                    bandeiras.add(bandeira);
                }
            }

        } catch (ClassNotFoundException erro) {
            erro.printStackTrace();
            //throw new ExcecaoAcessoDados("Houve um problema de configuração");
        } catch (SQLException erro) {
            erro.printStackTrace();
            //throw new ExcecaoAcessoDados("Houve um problema de conectividade");
        } finally {
            try {
                pst.close();
                conexao.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return bandeiras;

    }

    @Override
    public int salvarId(EntidadeDominio entidade) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<EntidadeDominio> filtrar(EntidadeDominio entidade) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}

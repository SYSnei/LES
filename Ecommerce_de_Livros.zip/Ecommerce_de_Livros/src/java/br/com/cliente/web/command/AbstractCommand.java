package br.com.cliente.web.command;

import br.com.cliente.core.fachada.IFachada;
import br.com.cliente.core.fachada.Fachada;

/**
 *
 * @author hisak
 */
public abstract class AbstractCommand implements ICommand{
    
    protected IFachada fachada = new Fachada();
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.cliente.web.vh;

import br.com.cliente.core.fachada.Resultado;
import br.com.cliente.core.util.ConverteDate;
import br.com.cliente.dominio.Livro;
import br.com.cliente.dominio.EntidadeDominio;
import br.com.cliente.web.command.ConsultarCommand;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import org.apache.tomcat.util.codec.binary.Base64;
import org.apache.tomcat.util.buf.UDecoder;
import org.apache.tomcat.util.codec.binary.Base64;
import org.apache.tomcat.util.http.fileupload.servlet.ServletFileUpload;
import java.util.Enumeration;
import sun.misc.FloatingDecimal;

/**
 *
 * @author hisak
 */
public class LivroViewHelper implements IViewHelper {

    //Objetos necessários para cadastrar um Cliente
    Livro livro;

    @Override
    public EntidadeDominio getEntidade(HttpServletRequest request) {

        //Recebe operação do formulário, na request.
        String operacao = request.getParameter("operacao");

        if (operacao.equals("SALVAR")) {

            livro = new Livro();

            //Dados referentes ao cliente
            String titulo = request.getParameter("titulo");
            String autor = request.getParameter("autor");
            String descricao = request.getParameter("descricao");
            String isbn = request.getParameter("isbn");
            String ano = request.getParameter("ano");
            String editora = request.getParameter("editora");
            String paginas = request.getParameter("paginas");
            String situacao = request.getParameter("situacao");
            String preco1 = request.getParameter("preco");            
            Double preco = 0.00;

            
            preco = Double.valueOf(preco1);

            //Setando os valores do cliente
            livro.setTitulo(titulo);
            livro.setAutor(autor);
            livro.setDescricao(descricao);
            livro.setIsbn(isbn);
            livro.setAno(ano);
            livro.setEditora(editora);
            livro.setPaginas(paginas);
            livro.setSituacao(situacao);
            livro.setPreco(preco);

            try {

            
                if (ServletFileUpload.isMultipartContent(request)) {

                    Part imagemFoto = request.getPart("foto");

                    String fotoBase64 = new Base64()
                            .encodeBase64String(converteStremParabyte(imagemFoto.getInputStream()));

                    livro.setFotoBase64(fotoBase64);
                    livro.setContentType(imagemFoto.getContentType());
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            

            return livro;

        }

        if (operacao.equals("ATUALIZARLIVROS")) {

            livro = new Livro();
            
            String id = request.getParameter("id");
            String titulo = request.getParameter("titulo");
            String autor = request.getParameter("autor");
            String descricao = request.getParameter("descricao");
            String isbn = request.getParameter("isbn");
            String ano = request.getParameter("ano");
            String editora = request.getParameter("editora");
            String paginas = request.getParameter("paginas");
            String situacao = request.getParameter("situacao");
            Double preco = 0.00;
            if (request.getParameter("preco") != null){
                preco = Double.valueOf(request.getParameter("preco"));
            }
            else{
                preco = 0.00;
            }
                      
            
            livro.setId(Integer.parseInt(id));

            if (titulo != null && !titulo.trim().equals("")) {
                livro.setTitulo(titulo);
            }

            if (autor != null && !autor.trim().equals("")) {
                livro.setAutor(autor);
            }

            if (descricao != null && !descricao.trim().equals("")) {
                livro.setDescricao(descricao);
            }

            if (isbn != null && !isbn.trim().equals("")) {
                livro.setIsbn(isbn);
            }

            if (ano != null && !ano.trim().equals("")) {
                livro.setAno(ano);
            }

            if (editora != null && !editora.trim().equals("")) {
                livro.setEditora(editora);
            }

            if (paginas != null && !paginas.trim().equals("")) {
                livro.setPaginas(paginas);
            }
            if (situacao != null && !situacao.trim().equals("")) {
                livro.setSituacao(situacao);
            }
            livro.setPreco(preco);
            
            try {

            
               /* if (ServletFileUpload.isMultipartContent(request)) {

                    Part imagemFoto = request.getPart("foto");

                    String fotoBase64 = new Base64()
                            .encodeBase64String(converteStremParabyte(imagemFoto.getInputStream()));
                    if (fotoBase64!=null){
                        livro.setFotoBase64(fotoBase64);
                        livro.setContentType(imagemFoto.getContentType());
                    }
                }*/
            } catch (Exception e) {
                e.printStackTrace();
            }
            

            return livro;

        }

        if (operacao.equals("CONSULTARLIVROS")) {

            String id = request.getParameter("id");
            livro = new Livro();
            if (id != null && !id.equals("")) {

                livro.setId(Integer.parseInt(id));

                return livro;

            } else {
                livro = new Livro();

                return livro;
            }
        } // fim consultar
        String uri = request.getRequestURI();
        if (uri.equals("/Ecommerce/preAtualizar")) {
            operacao = "PREATUALIZAR";
        }
        if (operacao.equals("EXCLUIRLIVROS")) {

            livro = new Livro();
            livro.setId(Integer.parseInt(request.getParameter("id")));

            return livro;

        }// fim excluir (ATIVAR/DESATIVAR)

       if (operacao.equals("PREATUALIZAR")) {
            livro = new Livro();

            String id = request.getParameter("id");

            if (id != null && !id.trim().equals("")) {

                livro.setId(Integer.parseInt(id));

                return livro;

            } else {

                return livro;
            }
        } // PREATUALIZAR

        if (operacao.equals("LISTARLIVROS")) {
            livro = new Livro();

           String id = request.getParameter("id");
            
            if (id != null && !id.equals("")) {

                livro.setId(Integer.parseInt(id));
            } else {

                return livro;
            }

        }
        if (operacao.equals("HOME")) {
            livro = new Livro();

            String id = request.getParameter("id");

            if (id != null && !id.trim().equals("")) {

                livro.setId(Integer.parseInt(id));

                return livro;

            } else {

                return livro;
            }
        }
        return livro;
    }

    @Override
    public void setView(Resultado resultado, HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        RequestDispatcher rd = null;

        //Recebe operação do formulário, na request.
        String operacao = request.getParameter("operacao");

        if (operacao.equals("SALVAR")) {

            if (resultado.getMsg() != null && !resultado.getMsg().trim().equals("")) {
                request.getSession().setAttribute("mensagem", resultado.getMsg());
                request.getSession().setAttribute("status", "danger");
                rd = request.getRequestDispatcher("livro.jsp");

            } else {

                request.getSession().setAttribute("resultado", resultado.getEntidades());
                request.getSession().setAttribute("mensagem", "Livro cadastrado com sucesso!");
                request.getSession().setAttribute("status", "success");
                //request.getSession().setAttribute("auditoria", resultado.getEntidade());
                rd = request.getRequestDispatcher("livro.jsp");
            }
        } else if (operacao.equals("ATUALIZARLIVROS")) {
            if (resultado.getMsg() != null) {
                request.getSession().setAttribute("mensagem", resultado.getMsg());
                request.getSession().setAttribute("resultado", resultado.getEntidades());
                rd = request.getRequestDispatcher("livro.jsp");

            } else {
                ConsultarCommand consulta = new ConsultarCommand();
                livro = new Livro();
                livro.setId(Integer.parseInt(request.getParameter("id")));
                resultado = consulta.execute(livro);
                request.getSession().setAttribute("resultado", resultado.getEntidades());
                request.getSession().setAttribute("mensagem", "Livro atualizado com sucesso!");
                request.getSession().setAttribute("status", "success");
                //request.getSession().setAttribute("auditoria", resultado.getEntidade());
                rd = request.getRequestDispatcher("listar_livro.jsp");
            }
        } else if (operacao.equals("CONSULTARLIVROS")) {

            if (resultado.getMsg() != null) {
                request.getSession().setAttribute("mensagem", resultado.getMsg());
                //request.getSession().setAttribute("auditoria", resultado.getEntidade());
                rd = request.getRequestDispatcher("listar_livro.jsp");

            } else {
                request.getSession().setAttribute("resultado", resultado.getEntidades());
                //request.getSession().setAttribute("auditoria", resultado.getEntidade());
                rd = request.getRequestDispatcher("listar_livro.jsp");
            }

        } //fim consultar
        else if (operacao.equals("PREATUALIZAR")) {

            if (resultado.getMsg() != null) {
                request.getSession().setAttribute("mensagem", resultado.getMsg());

                rd = request.getRequestDispatcher("livro.jsp");

            } else {
                request.getSession().setAttribute("resultado", resultado.getEntidades());

                rd = request.getRequestDispatcher("livro.jsp");
                request.getSession().setAttribute("resultado", resultado.getEntidades());
                request.getSession().setAttribute("mensagem", null);
            }

        } //fim consultar
        else if (operacao.equals("LISTARLIVROS")) {

            if (resultado.getMsg() != null) {
                request.getSession().setAttribute("mensagem", resultado.getMsg());

                rd = request.getRequestDispatcher("listar_livro.jsp");

            } else {
                if (resultado.getEntidades().isEmpty()) {
                    request.getSession().setAttribute("mensagem", "Não há nenhum livro cadastrado no sistema com este nome!");
                    request.getSession().setAttribute("resultado", null);
                    request.getSession().setAttribute("status", "danger");
                } else {
                    request.getSession().setAttribute("resultado", resultado.getEntidades());
                    request.getSession().setAttribute("mensagem", null);
                }

                rd = request.getRequestDispatcher("listar_livro.jsp");
            }

        } else if (operacao.equals("HOME")) {

            if (resultado.getMsg() != null) {
                request.getSession().setAttribute("mensagem", resultado.getMsg());

                rd = request.getRequestDispatcher("livro.jsp");

            } else {
                request.getSession().setAttribute("resultado", resultado.getEntidades());
                request.getSession().setAttribute("mensagem", null);

                rd = request.getRequestDispatcher("listar_livro.jsp");
            }

        } else if (operacao.equals("EXCLUIRLIVROS")) {
            if (resultado.getMsg() != null) {
                request.getSession().setAttribute("mensagem", resultado.getMsg());

                rd = request.getRequestDispatcher("listar_livro.jsp");

            } else {
                request.getSession().setAttribute("resultado", resultado.getEntidade());

                rd = request.getRequestDispatcher("listar_livro.jsp");
            }
        } else if (operacao.equals("AUTENTICAR")) {
            if (resultado.getMsg() != null) {
                request.getSession().setAttribute("mensagem", resultado.getMsg());

                rd = request.getRequestDispatcher("livro.jsp");

            } else {
                request.getSession().setAttribute("resultado", resultado.getEntidades());

                rd = request.getRequestDispatcher("livro.jsp");
            }

        }

        rd.forward(request, response);
    }

    private byte[] converteStremParabyte(InputStream imagem) throws Exception {

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        int reads = imagem.read();
        while (reads != -1) {
            baos.write(reads);
            reads = imagem.read();
        }

        return baos.toByteArray();

    }

}

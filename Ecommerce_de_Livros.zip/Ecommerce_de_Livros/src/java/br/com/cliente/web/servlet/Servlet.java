
package br.com.cliente.web.servlet;

import br.com.cliente.core.fachada.Resultado;
import br.com.cliente.dominio.Livro;
import br.com.cliente.dominio.EntidadeDominio;
import br.com.cliente.web.command.AtualizarCommand;
import br.com.cliente.web.command.ConsultarCommand;
import br.com.cliente.web.command.ExcluirCommand;
import br.com.cliente.web.command.FiltrarCommand;
import br.com.cliente.web.command.ICommand;
import br.com.cliente.web.command.SalvarCommand;
import br.com.cliente.web.command.VisualizarCommand;
import br.com.cliente.web.vh.IViewHelper;
import br.com.cliente.web.vh.LivroViewHelper;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author hisak
 */

@MultipartConfig
public class Servlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private static Map<String, ICommand> commands;
    private static Map<String, IViewHelper> vhs;

    /**
     * Default constructor.
     */
    public Servlet() {

        /* Utilizando o command para chamar a fachada e indexando cada command de acordo com a operação
    	 * pela operação garantimos que esta servelt atenderá qualquer operação da uri */
        
        
        commands = new HashMap<String, ICommand>();

        // (instancia dentro do contrutor) -  So haverá um objeto se realmente a classe for instanciada.
        
        commands.put("SALVAR", new SalvarCommand());
        commands.put("EXCLUIRLIVROS", new ExcluirCommand());
        commands.put("CONSULTARLIVROS", new ConsultarCommand());
        commands.put("PREATUALIZAR", new ConsultarCommand());
        commands.put("HOME", new ConsultarCommand());
        commands.put("VISUALIZAR", new VisualizarCommand());
        commands.put("ATUALIZARLIVROS", new AtualizarCommand());
        commands.put("AUTENTICAR", new ConsultarCommand());
        commands.put("LISTARLIVROS", new ConsultarCommand());
        
        /* Utilizando o ViewHelper para tratar especificações de qualquer tela e indexando 
    	 cada viewhelper pela url em que esta servelet chama, de acordo com o form 
    	 garantimos que esta servelt atenderá qualquer entidade */
        
        vhs = new HashMap<String, IViewHelper>();
        
        /*A chave do mapa é o mapeamento da servlet para cada form que 
    	   está configurado no web.xml e sendo utilizada no action do html
         */
        vhs.put("/Ecommerce_de_Livros/salvar", new LivroViewHelper());
        vhs.put("/Ecommerce_de_Livros/atualizarLivros", new LivroViewHelper());
        vhs.put("/Ecommerce_de_Livros/consultarLivros", new LivroViewHelper());
        vhs.put("/Ecommerce_de_Livros/filtar", new LivroViewHelper());
        vhs.put("/Ecommerce_de_Livros/autenticar", new LivroViewHelper());
        vhs.put("/Ecommerce_de_Livros/listarLivros", new LivroViewHelper());        
        vhs.put("/Ecommerce_de_Livros/excluirLivros", new LivroViewHelper());
        vhs.put("/Ecommerce_de_Livros/preAtualizar", new LivroViewHelper());
        vhs.put("/Ecommerce_de_Livros/home", new LivroViewHelper());
        vhs.put("/Ecommerce_de_Livros/login", new LivroViewHelper());
       
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     * response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doProcessRequest(request, response);  }
    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     * response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        doProcessRequest(request, response);
    }

    protected void doProcessRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        //pega a uri de onde vem a requisição, indicada no action no form
        String uri = request.getRequestURI();

        //Obtem o objeto da viewHelper correta, mapeada no hash acima;
        IViewHelper vh = vhs.get(uri);

        //Vai retornar o objeto do dominio, que foi construído na viewhelper específica.
        EntidadeDominio entidade = vh.getEntidade(request);
        
        Livro livro = new Livro();        
       
        
        
        //Essa string recebe o valor do atributo "operacao" no formulário, que é do tipo hidden, e será utilizado para identificar o command no map
        String operacao = request.getParameter("operacao");

        //Obtem o objeto do comando que executará a operação
        ICommand command = commands.get(operacao);

        //Executa o commando que vai chamar a fachada para executar a operação requisitada
        //o retorno é uma instância da classe resultado que pode conter mensagens de erro ou entidades de retorno
        Resultado resultado = new Resultado();
        
        
            resultado = command.execute(entidade);
        

        //Chama o método para retornar a resposta para a view correta.
        vh.setView(resultado, request, response);

    }

    
    
    
    
    
}

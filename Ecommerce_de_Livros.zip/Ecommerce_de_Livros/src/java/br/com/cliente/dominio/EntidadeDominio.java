package br.com.cliente.dominio;

import java.io.Serializable;
import java.util.Date;


public abstract class EntidadeDominio implements Serializable{
    
        private Integer id;
   
    private Date dtCadastro;

    public Integer getId() {
            return id;
    }
    public void setId(Integer id) {
            this.id = id;
    }
    public Date getDtCadastro() {
            return dtCadastro;
    }
    public void setDtCadastro(Date dtCadastro) {
            this.dtCadastro = dtCadastro;
    }
    
    
}

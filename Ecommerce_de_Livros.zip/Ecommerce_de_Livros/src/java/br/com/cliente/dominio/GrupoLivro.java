package br.com.cliente.dominio;


public class GrupoLivro extends EntidadeDominio {
	private Integer id;
	private String nome;
	private Double margemLucro;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public Double getMargemLucro() {
		return margemLucro;
	}
	public void setMargemLucro(Double margemLucro) {
		this.margemLucro = margemLucro;
	}
	
}

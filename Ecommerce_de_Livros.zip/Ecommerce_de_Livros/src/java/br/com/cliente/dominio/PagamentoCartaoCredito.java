package br.com.cliente.dominio;


public class PagamentoCartaoCredito extends EntidadeDominio {
	private Cartao cartaoCredito;
	private Double valor;
	
	public Cartao getCartaoCredito() {
		return cartaoCredito;
	}
	public void setCartaoCredito(Cartao cartaoCredito) {
		this.cartaoCredito = cartaoCredito;
	}
	public Double getValor() {
		return valor;
	}
	public void setValor(Double valor) {
		this.valor = valor;
	}
	
}

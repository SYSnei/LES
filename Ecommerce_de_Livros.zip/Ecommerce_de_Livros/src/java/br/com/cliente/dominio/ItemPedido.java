package br.com.cliente.dominio;


public class ItemPedido extends ItemLivro {
	private Pedido pedido;
	private Livro livro;
	
	public ItemPedido() {
		livro = new Livro();
		pedido = new Pedido();
	}

	public Pedido getPedido() {
		return pedido;
	}

	public void setPedido(Pedido pedido) {
		this.pedido = pedido;
	}

	public Livro getLivro() {
		return livro;
	}

	public void setLivro(Livro livro) {
		this.livro = livro;
	}
	
}

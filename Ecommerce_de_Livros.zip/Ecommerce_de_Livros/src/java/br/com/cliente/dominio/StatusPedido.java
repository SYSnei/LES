package br.com.cliente.dominio;


public class StatusPedido extends EntidadeDominio {
	private Integer id;
	private String status;
	private StatusPedido proximoStatus;
	private static final Integer EM_PROCESSO = 1;
	private static final Integer EM_TRANSPORTE = 2;
	private static final Integer ENTREGUE = 3;
	private static final Integer EM_TROCA = 4;
	private static final Integer APROVADO = 5;
	private static final Integer REPROVADO = 6;
	private static final Integer TROCADO = 7;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public StatusPedido getProximoStatus() {
		return proximoStatus;
	}
	public void setProximoStatus(StatusPedido proximoStatus) {
		this.proximoStatus = proximoStatus;
	}
	
}

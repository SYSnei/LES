package br.com.cliente.dominio;

public class Item extends EntidadeDominio {
	private Integer quantidade;
	private Livro livro;
	private Float custo;
	private Fornecedor fornecedor;
	
	public Item() {
		livro = new Livro();
		fornecedor = new Fornecedor();
	}

	public Integer getQuantidade() {
		return quantidade;
	}

	public void setQuantidade(Integer quantidade) {
		this.quantidade = quantidade;
	}

	public Livro getLivro() {
		return livro;
	}

	public void setLivro(Livro livro) {
		this.livro = livro;
	}

	public Float getCusto() {
		return custo;
	}

	public void setCusto(Float custo) {
		this.custo = custo;
	}

	public Fornecedor getFornecedor() {
		return fornecedor;
	}

	public void setFornecedor(Fornecedor fornecedor) {
		this.fornecedor = fornecedor;
	}
	
}

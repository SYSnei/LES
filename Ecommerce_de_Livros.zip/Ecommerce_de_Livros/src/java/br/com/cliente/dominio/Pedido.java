package br.com.cliente.dominio;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;


public class Pedido extends EntidadeDominio {
	private Integer id;
	private String tipo;
	private Cliente cliente;
	private List<ItemPedido> itens;
	private Endereco endereco;
	private Pagamento pagamento;
	private Date dtPedido;
	private StatusPedido statusPedido;
	private Cupom cupom;
	private ItemLivro item;
	
	public Pedido() {
		cliente = new Cliente();
		endereco = new Endereco();
		cupom = new Cupom();
		statusPedido = new StatusPedido();
		item = new ItemLivro();
		pagamento = new Pagamento();
		List<PagamentoCartaoCredito> pagamentos = new ArrayList<PagamentoCartaoCredito>();
		pagamento.setPagamentosCartao(pagamentos);
		this.setPagamento(pagamento);
		
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public List<ItemPedido> getItens() {
		return itens;
	}

	public void setItens(List<ItemPedido> itens) {
		this.itens = itens;
	}

	public Endereco getEndereco() {
		return endereco;
	}

	public void setEndereco(Endereco endereco) {
		this.endereco = endereco;
	}

	public Pagamento getPagamento() {
		return pagamento;
	}

	public void setPagamento(Pagamento pagamento) {
		this.pagamento = pagamento;
	}

	public Date getDtPedido() {
		return dtPedido;
	}

	public void setDtPedido(Date dtPedido) {
		this.dtPedido = dtPedido;
	}

	public StatusPedido getStatusPedido() {
		return statusPedido;
	}

	public void setStatusPedido(StatusPedido statusPedido) {
		this.statusPedido = statusPedido;
	}

	public Cupom getCupom() {
		return cupom;
	}

	public void setCupom(Cupom cupom) {
		this.cupom = cupom;
	}

	public ItemLivro getItem() {
		return item;
	}

	public void setItem(ItemLivro item) {
		this.item = item;
	}
	
}

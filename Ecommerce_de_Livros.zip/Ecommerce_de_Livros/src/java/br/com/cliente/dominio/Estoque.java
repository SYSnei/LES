package br.com.cliente.dominio;

public class Estoque extends EntidadeDominio {
	private Item item;
	
	public Estoque() {
		item = new Item();
	}
	public Item getItem() {
		return item;
	}
	public void setItem(Item item) {
		this.item = item;
	}
	
}

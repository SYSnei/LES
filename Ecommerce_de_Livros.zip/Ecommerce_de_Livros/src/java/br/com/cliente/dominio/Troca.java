package br.com.cliente.dominio;

import java.util.Date;

public class Troca extends EntidadeDominio {
	private Integer id;
	private Cliente cliente;
	private Pedido pedido;
	private Date dataTroca;
	private String status;
	
	public Troca() {
		pedido = new Pedido();
		cliente = new Cliente();
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public Pedido getPedido() {
		return pedido;
	}

	public void setPedido(Pedido pedido) {
		this.pedido = pedido;
	}

	public Date getDataTroca() {
		return dataTroca;
	}

	public void setDataTroca(Date dataTroca) {
		this.dataTroca = dataTroca;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
}

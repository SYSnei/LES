package br.com.cliente.dominio;

import java.util.ArrayList;
import java.util.List;

public class Carrinho extends EntidadeDominio {
	private Integer id;
	private int quantidadeItens;
	private List<Livro> livros;
	private ArrayList<Livro> liv = new ArrayList<Livro>();
	private Livro livro;
	private Cliente cliente;
	
	public Carrinho() {
		livro = new Livro();
		cliente = new Cliente();
	}
	
	public Carrinho(Integer id, int quantidadeItens, List<Livro> livros) {
		this.id = id;
		this.quantidadeItens = quantidadeItens;
		this.livros = livros;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public int getQuantidadeItens() {
		return quantidadeItens;
	}

	public void setQuantidadeItens(int quantidadeItens) {
		this.quantidadeItens = quantidadeItens;
	}

	public List<Livro> getLivros() {
		return livros;
	}

	public void setLivros(List<Livro> livros) {
		this.livros = livros;
	}

	public ArrayList<Livro> getLiv() {
		return liv;
	}

	public void setLiv(ArrayList<Livro> liv) {
		this.liv = liv;
	}

	public Livro getLivro() {
		return livro;
	}

	public void setLivro(Livro livro) {
		this.livro = livro;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}
	
}

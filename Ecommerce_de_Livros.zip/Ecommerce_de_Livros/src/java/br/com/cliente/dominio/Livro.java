
package br.com.cliente.dominio;


public class Livro extends EntidadeDominio {
    
    private String titulo;
    private String autor;
    private String descricao;
    private String isbn;
    private String ano;
    private String editora;
    private String paginas;
    private String situacao;
    private Double preco;
    private String fotoBase64;
    private String contentType;	
    private String tempFotoUser;
	
    public String getTempFotoUser() {
		
		tempFotoUser= "data:" + contentType + ";base64," + fotoBase64;
		
		return tempFotoUser;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getAutor() {
        return autor;
    }

    public String getDescricao() {
        return descricao;
    }

    public String getIsbn() {
        return isbn;
    }

    public String getAno() {
        return ano;
    }

    public String getEditora() {
        return editora;
    }

    public String getPaginas() {
        return paginas;
    }

    public String getSituacao() {
        return situacao;
    }

    public Double getPreco() {
        return preco;
    }

    public String getFotoBase64() {
        return fotoBase64;
    }

    public String getContentType() {
        return contentType;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public void setAno(String ano) {
        this.ano = ano;
    }

    public void setEditora(String editora) {
        this.editora = editora;
    }

    public void setPaginas(String paginas) {
        this.paginas = paginas;
    }

    public void setSituacao(String situacao) {
        this.situacao = situacao;
    }

    public void setPreco(Double preco) {
        this.preco = preco;
    }

    public void setFotoBase64(String fotoBase64) {
        this.fotoBase64 = fotoBase64;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public void setTempFotoUser(String tempFotoUser) {
        this.tempFotoUser = tempFotoUser;
    }
	
    
    
    
    
    
    
    
    
}
